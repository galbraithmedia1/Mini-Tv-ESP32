var searchData=
[
  ['findsynchword_29',['findSynchWord',['../classlibhelix_1_1_a_a_c_decoder_helix.html#ab0a51525154362d7219f9895de160b63',1,'libhelix::AACDecoderHelix::findSynchWord()'],['../classlibhelix_1_1_common_helix.html#a4196bcaf7e85ad7807dea0c671a7647b',1,'libhelix::CommonHelix::findSynchWord()'],['../classlibhelix_1_1_m_p3_decoder_helix.html#a358f27530f91ab074a648bb0748410ac',1,'libhelix::MP3DecoderHelix::findSynchWord()']]],
  ['framerange_30',['frameRange',['../classlibhelix_1_1_common_helix.html#a40e201771b274b3033b30cec2661d025',1,'libhelix::CommonHelix']]]
];
