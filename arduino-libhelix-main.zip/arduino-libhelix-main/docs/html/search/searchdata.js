var indexSectionsWithContent =
{
  0: "abcdefhmorsw",
  1: "acmr",
  2: "abdefmosw",
  3: "h"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Pages"
};

